Place your XML documents in this folder.
