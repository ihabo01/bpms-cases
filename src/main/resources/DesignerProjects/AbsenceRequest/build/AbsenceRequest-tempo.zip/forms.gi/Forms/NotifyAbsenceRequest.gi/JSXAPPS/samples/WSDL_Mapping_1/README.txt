Classes:
jsx3.app.Server
jsx3.gui.TextBox
jsx3.lang.Package
jsx3.net.Request
jsx3.net.Service
String

Methods:
eg.wsdl1.doTest()
eg.wsdl1.onMySuccess()
eg.wsdl1.onMyError()
eg.wsdl1.showCountyAlert()
jsx3.app.Server.alert()
jsx3.gui.TextBox.getValue()
jsx3.gui.TextBox.setValue()
jsx3.lang.Package.definePackage()
jsx3.net.Request.getRequest()
jsx3.net.Request.getStatus()
jsx3.net.Service.doCall()
jsx3.net.Service.subscribe()

Constants:
MESSAGENODE
ON_SUCCESS
ON_ERROR
